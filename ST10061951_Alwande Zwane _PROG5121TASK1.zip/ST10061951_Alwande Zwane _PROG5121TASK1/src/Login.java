/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zwame
 */
 import java. util.Scanner ;
public class Login {
       
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        // Declaration of the data types 
        String firstname ,lastname;
        String username, password;
        //Giving out instructions or prompts to the user to put their password, username , first and last names.
        System.out.println(" please enter your firstname");
        firstname=input.nextLine();
        System.out.println("please enter your lastname");
        lastname=input.nextLine();
        System.out.println("please enter your username");
        username=input.nextLine();
        System.out.println("please enter your password");
        password=input.nextLine();
       
        System.out.println(Login.registerUser(username, password));
        
        System.out.println("Enter username: ");
        String doLogin = input.next();
        System.out.println("Enter password: ");
        String letLogin = input.next();
        
        System.out.println(Login.returnLoginStatus(username, password, doLogin, letLogin, firstname, lastname));
  
    }
      // checking whether the length of the username is 5 or less and has an underscore;
    public static boolean checkUserName(String username){
        int length=username.length();boolean doLength=false;boolean areLength=false;
       if (length <=5){
                doLength=true;     
            }
        for(int i=0;i<length;i ++){
            if (username.charAt(i)==95){
               areLength = true;
            }
           
            if (areLength == true && doLength == true){
                return true;
            }
            } 
        return false;
    } 
    public static boolean checkPasswordComplexity(String password){
            // checking whether password has eight characters,capital letter, a number and special letter
        int length =password.length();
        boolean passwordlength=false;
        boolean upperCase=false;
        boolean number=false;
        boolean specialCharacters=false;
        
        if(length>=8){
            passwordlength = true; 
        }
        for(int b =0;b<length;b++){
            if(password.charAt(b)>=65&&password.charAt(b)<=90){
                upperCase = true;
            } 
            else if((password.charAt(b)<=33&&password.charAt(b)>=47)||(password.charAt(b)<=58 && password.charAt(b)>=64)||(password.charAt(b)<=91 && password.charAt(b) >=96)|| (password.charAt(b)>=123 && password.charAt(b) <=126));
            specialCharacters=true;
            if(password.charAt(b)>=48 && password.charAt(b)<=57)
             number=true;  
        } 
        if(passwordlength == true&& upperCase==true && number==true && specialCharacters== true){
            return true;
        }
       return false;
              
        }
    public static String registerUser(String username,String password){
         boolean doRight = Login.checkUserName(username);
         boolean goRight = Login.checkPasswordComplexity(password);
         
         
   
         if(doRight == true){
             if(goRight == true){
                 System.out.println("Username correctly formatted");
                 System.out.println("Password successfully captured");
             }
             
         }
         if(doRight == true){
             if(goRight == false){
                 System.out.println("Username correctly formatted"); 
                 System.out.println("Password incorrectly formatted");
             }
         }
         if(doRight == false){
             if(goRight == true){
                 System.out.println("username is not correctly formatted,please ensure that your username contains an underscore and is no more than 5 characters in length");
                 System.out.println("password correctly formatted");
             }
         }
         if(doRight == false){
             if(goRight == false){
                 System.out.println("username is not correctly forrmatted ,please ensure that your username contains an underscore and is no more than 5 characters in length");
                 System.out.println("password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter and a special character");
             }
         }
         return " ";
         
         
        }
        public static boolean loginUser(String username,String password,String doLogin,String getLogin){
            if(username.equals(doLogin)&&(password.equals(getLogin))){
                return true;
                
            }
            return false;
        }
        public static String returnLoginStatus(String username,String password,String doLogin,String getLogin,String firstname,String lastname){
            if(Login.loginUser(username, doLogin, getLogin, password)== true){
                return "Welcome back,"+firstname+" "+lastname+ " it is great to see you" ;           
            }  
            
         return "Login unsuccessful";   
        }
}      